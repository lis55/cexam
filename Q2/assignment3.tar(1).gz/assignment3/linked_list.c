#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// data structure of a node
struct Node
{
  char name[256];    // the name of the node
  struct Node *Next; // pointer to the next node
};

// the start (head) of the linked list
struct Node *LinkedList=NULL;

void InsertNode(char *name)
{
  struct Node *old_head;

  old_head=LinkedList;
  LinkedList=(struct Node*)calloc(1,sizeof(struct Node));
  LinkedList->Next=old_head;
  strcpy(LinkedList->name,name);
}

void PrintList(void)
{
  int nr;
  struct Node *temp;

  nr=0;
  temp=LinkedList;
  while(temp)
  {
    printf("Node number: %d name: %s\n",nr++,temp->name);
    temp=temp->Next;
  }
}


int main(void)
{
  InsertNode("node one");
  InsertNode("node two");
  InsertNode("node three");
  PrintList();
  return 0;
}
